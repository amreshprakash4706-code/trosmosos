-- Trosmos OS 5.0 core schema
-- Per-user operating environment: VFS, workspaces, productivity, AI, jobs.

create table if not exists os_profiles (
  user_id text primary key,
  display_name text,
  username text,
  timezone text not null default 'UTC',
  role text not null default 'user' check (role in ('user', 'admin')),
  storage_used bigint not null default 0,
  bootstrapped_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists workspaces (
  id text primary key,
  user_id text not null,
  name text not null,
  color text,
  is_active boolean not null default false,
  is_favorite boolean not null default false,
  sort_order integer not null default 0,
  state_json text,
  settings_json text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists workspaces_user_idx on workspaces (user_id, is_active);
create index if not exists workspaces_user_sort_idx on workspaces (user_id, sort_order);

create table if not exists vfs_nodes (
  id text primary key,
  user_id text not null,
  workspace_id text,
  parent_id text,
  name text not null,
  path text not null,
  is_dir boolean not null default false,
  mime_type text,
  size integer not null default 0,
  content text,
  content_encoding text not null default 'utf8',
  content_hash text,
  is_trashed boolean not null default false,
  trashed_at timestamptz,
  original_path text,
  version integer not null default 1,
  metadata_json text,
  accessed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, path)
);
create index if not exists vfs_user_parent_idx on vfs_nodes (user_id, parent_id, is_trashed);
create index if not exists vfs_user_path_idx on vfs_nodes (user_id, path);
create index if not exists vfs_user_trashed_idx on vfs_nodes (user_id, is_trashed, trashed_at);
create index if not exists vfs_user_name_idx on vfs_nodes (user_id, name);
create index if not exists vfs_user_mime_idx on vfs_nodes (user_id, mime_type);
create index if not exists vfs_user_ws_idx on vfs_nodes (user_id, workspace_id);

create table if not exists vfs_versions (
  id text primary key,
  file_id text not null references vfs_nodes(id) on delete cascade,
  user_id text not null,
  version integer not null,
  size integer not null default 0,
  content text,
  content_encoding text not null default 'utf8',
  content_hash text,
  mime_type text,
  created_at timestamptz not null default now(),
  unique (file_id, version)
);
create index if not exists vfs_versions_file_idx on vfs_versions (file_id, version desc);
create index if not exists vfs_versions_user_idx on vfs_versions (user_id);

create table if not exists favorites (
  user_id text not null,
  path text not null,
  title text,
  created_at timestamptz not null default now(),
  primary key (user_id, path)
);

create table if not exists recent_items (
  id text primary key,
  user_id text not null,
  kind text not null,
  ref text not null,
  title text,
  path text,
  accessed_at timestamptz not null default now()
);
create index if not exists recent_user_idx on recent_items (user_id, accessed_at desc);

create table if not exists os_settings (
  user_id text not null,
  key text not null,
  value_json text not null,
  updated_at timestamptz not null default now(),
  primary key (user_id, key)
);

create table if not exists notifications (
  id text primary key,
  user_id text not null,
  title text not null,
  body text,
  type text not null default 'info',
  category text not null default 'system',
  priority text not null default 'normal',
  icon text,
  data_json text,
  is_read boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists notifications_user_idx on notifications (user_id, is_read, created_at desc);

create table if not exists apps_installed (
  id text primary key,
  user_id text not null,
  app_id text not null,
  version text,
  enabled boolean not null default true,
  settings_json text,
  installed_at timestamptz not null default now(),
  unique (user_id, app_id)
);
create index if not exists apps_installed_user_idx on apps_installed (user_id, enabled);

create table if not exists jobs (
  id text primary key,
  user_id text not null,
  type text not null,
  title text not null,
  status text not null default 'pending' check (status in ('pending','running','completed','failed','cancelled')),
  progress real not null default 0,
  payload_json text,
  result_json text,
  error text,
  attempts integer not null default 0,
  max_attempts integer not null default 3,
  run_after timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  completed_at timestamptz
);
create index if not exists jobs_user_idx on jobs (user_id, status, created_at desc);
create index if not exists jobs_queue_idx on jobs (status, run_after, created_at);

create table if not exists audit_logs (
  id text primary key,
  user_id text,
  action text not null,
  resource text,
  resource_id text,
  details_json text,
  correlation_id text,
  created_at timestamptz not null default now()
);
create index if not exists audit_user_idx on audit_logs (user_id, created_at desc);

create table if not exists capabilities (
  id text primary key,
  user_id text not null,
  scope text not null,
  resource text,
  granted_at timestamptz not null default now(),
  expires_at timestamptz,
  unique (user_id, scope, resource)
);
create index if not exists capabilities_user_idx on capabilities (user_id, scope);

create table if not exists ai_conversations (
  id text primary key,
  user_id text not null,
  workspace_id text,
  title text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists ai_conv_user_idx on ai_conversations (user_id, updated_at desc);

create table if not exists ai_messages (
  id text primary key,
  conversation_id text not null references ai_conversations(id) on delete cascade,
  user_id text not null,
  role text not null check (role in ('user','assistant','system','tool')),
  content text not null default '',
  tool_name text,
  tool_call_id text,
  metadata_json text,
  created_at timestamptz not null default now()
);
create index if not exists ai_msg_conv_idx on ai_messages (conversation_id, created_at);

create table if not exists ai_tool_invocations (
  id text primary key,
  user_id text not null,
  conversation_id text,
  tool_name text not null,
  args_json text not null,
  result_json text,
  status text not null check (status in ('pending','confirmed','executed','failed','denied','cancelled')),
  requires_confirmation boolean not null default false,
  correlation_id text,
  created_at timestamptz not null default now(),
  executed_at timestamptz
);
create index if not exists ai_inv_user_idx on ai_tool_invocations (user_id, status, created_at desc);

create table if not exists ai_memories (
  id text primary key,
  user_id text not null,
  kind text not null default 'explicit',
  content text not null,
  source text,
  created_at timestamptz not null default now()
);
create index if not exists ai_mem_user_idx on ai_memories (user_id, created_at desc);

create table if not exists notes (
  id text primary key,
  user_id text not null,
  workspace_id text,
  title text not null,
  path text,
  content text not null default '',
  preview text,
  tags_json text,
  pinned boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists notes_user_idx on notes (user_id, updated_at desc);
create index if not exists notes_ws_idx on notes (user_id, workspace_id);

create table if not exists todos (
  id text primary key,
  user_id text not null,
  workspace_id text,
  parent_id text,
  title text not null,
  notes text,
  status text not null default 'todo' check (status in ('todo','in_progress','done','cancelled')),
  priority text not null default 'medium' check (priority in ('low','medium','high','urgent')),
  due_at timestamptz,
  remind_at timestamptz,
  recurrence text,
  tags_json text,
  sort_order integer not null default 0,
  completed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists todos_user_idx on todos (user_id, status, due_at);
create index if not exists todos_parent_idx on todos (user_id, parent_id);

create table if not exists calendar_events (
  id text primary key,
  user_id text not null,
  workspace_id text,
  title text not null,
  description text,
  location text,
  starts_at timestamptz not null,
  ends_at timestamptz,
  all_day boolean not null default false,
  timezone text,
  recurrence text,
  todo_id text,
  remind_minutes integer,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists cal_user_idx on calendar_events (user_id, starts_at);

create table if not exists mutations (
  id text primary key,
  user_id text not null,
  op text not null,
  idempotency_key text not null,
  status text not null default 'applied',
  result_json text,
  created_at timestamptz not null default now(),
  unique (user_id, idempotency_key)
);
create index if not exists mutations_user_idx on mutations (user_id, created_at desc);

create table if not exists search_history (
  id text primary key,
  user_id text not null,
  query text not null,
  created_at timestamptz not null default now()
);
create index if not exists search_hist_user_idx on search_history (user_id, created_at desc);

create table if not exists clipboard_items (
  id text primary key,
  user_id text not null,
  text text not null,
  created_at timestamptz not null default now()
);
create index if not exists clip_user_idx on clipboard_items (user_id, created_at desc);

create table if not exists window_layouts (
  user_id text not null,
  workspace_id text not null,
  layout_json text not null,
  updated_at timestamptz not null default now(),
  primary key (user_id, workspace_id)
);
